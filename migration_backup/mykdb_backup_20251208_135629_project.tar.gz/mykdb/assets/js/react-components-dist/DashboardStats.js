/**
 * Dashboard Statistics Component
 * Displays real-time statistics cards for the dashboard
 */

const DashboardStats = () => {
  const [stats, setStats] = React.useState({
    published: 0,
    drafts: 0,
    pending: 0,
    approved: 0,
    totalArticles: 0,
    totalUsers: 0,
    onlineUsers: 0
  });
  const [loading, setLoading] = React.useState(true);

  // Fetch stats from API
  React.useEffect(() => {
    fetch('api/bkd_dashboard_stats.php').then(response => response.json()).then(data => {
      setStats(data);
      setLoading(false);
    }).catch(error => {
      console.error('Error fetching stats:', error);
      setLoading(false);
    });
  }, []);
  if (loading) {
    return /*#__PURE__*/React.createElement("div", {
      className: "stats-loading"
    }, /*#__PURE__*/React.createElement("p", null, "Loading statistics..."));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "dashboard-stats-container"
  }, /*#__PURE__*/React.createElement("h3", null, "\uD83D\uDCCA Statistics Overview"), /*#__PURE__*/React.createElement("div", {
    className: "stats-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-card articles-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-icon"
  }, "\uD83D\uDCDA"), /*#__PURE__*/React.createElement("div", {
    className: "stat-content"
  }, /*#__PURE__*/React.createElement("h4", null, "Articles This Month"), /*#__PURE__*/React.createElement("div", {
    className: "stat-details"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "stat-label"
  }, "Published:"), /*#__PURE__*/React.createElement("span", {
    className: "stat-value"
  }, stats.published)), /*#__PURE__*/React.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "stat-label"
  }, "Drafts:"), /*#__PURE__*/React.createElement("span", {
    className: "stat-value"
  }, stats.drafts)), /*#__PURE__*/React.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "stat-label"
  }, "Pending:"), /*#__PURE__*/React.createElement("span", {
    className: "stat-value"
  }, stats.pending)), /*#__PURE__*/React.createElement("div", {
    className: "stat-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "stat-label"
  }, "Approved:"), /*#__PURE__*/React.createElement("span", {
    className: "stat-value"
  }, stats.approved))))), /*#__PURE__*/React.createElement("div", {
    className: "stat-card total-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-icon"
  }, "\uD83D\uDCD6"), /*#__PURE__*/React.createElement("div", {
    className: "stat-content"
  }, /*#__PURE__*/React.createElement("h4", null, "Total Articles"), /*#__PURE__*/React.createElement("div", {
    className: "stat-number"
  }, stats.totalArticles), /*#__PURE__*/React.createElement("p", {
    className: "stat-subtitle"
  }, "All time"))), /*#__PURE__*/React.createElement("div", {
    className: "stat-card users-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-icon"
  }, "\uD83D\uDC65"), /*#__PURE__*/React.createElement("div", {
    className: "stat-content"
  }, /*#__PURE__*/React.createElement("h4", null, "Users"), /*#__PURE__*/React.createElement("div", {
    className: "stat-number"
  }, stats.totalUsers), /*#__PURE__*/React.createElement("div", {
    className: "online-status"
  }, /*#__PURE__*/React.createElement("span", {
    className: "online-indicator"
  }, "\uD83D\uDFE2"), /*#__PURE__*/React.createElement("span", null, stats.onlineUsers, " online"))))));
};

// Make it available globally
window.DashboardStats = DashboardStats;