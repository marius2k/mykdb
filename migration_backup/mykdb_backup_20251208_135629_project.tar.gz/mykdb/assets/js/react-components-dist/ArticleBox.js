const ArticleBox = ({
  article,
  onBookmarkToggle,
  onVote,
  isBookmarked = false,
  currentVote = null,
  appUrl = '/mykdb/',
  lang = {
    author: 'Author',
    category: 'Category',
    published: 'Published',
    updated: 'Updated'
  }
}) => {
  // Helper to check if icon is a file path
  const isIconFile = icon => {
    return icon && (icon.startsWith('http') || icon.endsWith('.png') || icon.endsWith('.svg'));
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "article-card"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    className: "article-title"
  }, article.icon && /*#__PURE__*/React.createElement(React.Fragment, null, isIconFile(article.icon) ? /*#__PURE__*/React.createElement("a", {
    href: `index.php?fcategory=${article.catid}`,
    title: article.category
  }, /*#__PURE__*/React.createElement("img", {
    src: `${appUrl}assets/icons/categories/${article.icon}`,
    alt: "icon",
    className: "me-1",
    style: {
      width: '35px',
      verticalAlign: 'middle'
    }
  })) : /*#__PURE__*/React.createElement("span", {
    className: "me-1"
  }, article.icon)), article.title), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: '15px',
      paddingRight: '10px'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: `${appUrl}assets/icons/icon-bookmark-${isBookmarked ? 'full' : 'empty'}.svg`,
    alt: "Bookmark",
    className: "bookmark-icon",
    style: {
      cursor: 'pointer',
      width: '30px',
      height: 'auto'
    },
    onClick: () => onBookmarkToggle(article.id),
    title: isBookmarked ? 'Remove from favorites' : 'Add to favorites'
  }))), article.tags && article.tags.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "article-tags",
    style: {
      margin: '6px 10px',
      paddingBottom: '10px'
    }
  }, article.tags.map((tag, index) => /*#__PURE__*/React.createElement("span", {
    key: index,
    className: "tag-badge-1"
  }, /*#__PURE__*/React.createElement("a", {
    href: `articles_by_tag.php?tag=${encodeURIComponent(tag)}`
  }, tag)))), /*#__PURE__*/React.createElement("div", {
    className: "article-body",
    id: `article${article.id}`
  }, /*#__PURE__*/React.createElement("p", null, article.shortText.split('\n').map((line, i) => /*#__PURE__*/React.createElement("span", {
    key: i
  }, line, i < article.shortText.split('\n').length - 1 && /*#__PURE__*/React.createElement("br", null))), /*#__PURE__*/React.createElement("a", {
    href: `view_article.php?id=${article.id}`
  }, /*#__PURE__*/React.createElement("img", {
    width: "24",
    height: "auto",
    src: `${appUrl}assets/icons/icon-read-more.svg`,
    title: "Read more"
  })))), /*#__PURE__*/React.createElement("div", {
    className: "article-footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "article-meta-section"
  }, /*#__PURE__*/React.createElement("span", {
    className: "article-meta"
  }, lang.author, ": ", article.username, " | ", lang.category, ": ", article.category, " | ", lang.published, ": ", article.publishedAt, " | ", lang.updated, ": ", article.updatedAt)), /*#__PURE__*/React.createElement("div", {
    className: "vote-buttons-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "vote-buttons",
    id: `meta-${article.id}`
  }, /*#__PURE__*/React.createElement("a", {
    href: `${appUrl}public/view_article.php?id=${article.id}&version=${article.version}&isonline=1`
  }, /*#__PURE__*/React.createElement("img", {
    src: `${appUrl}assets/images/icon-view.png`,
    title: "Views",
    className: "vote-icon"
  })), /*#__PURE__*/React.createElement("span", {
    className: "view-count"
  }, article.viewsCount || 0), /*#__PURE__*/React.createElement("a", {
    href: `${appUrl}public/view_article.php?id=${article.id}#comments`
  }, /*#__PURE__*/React.createElement("img", {
    src: `${appUrl}assets/images/icon-comm.png`,
    title: "Comments",
    className: "vote-icon"
  })), /*#__PURE__*/React.createElement("span", {
    className: "comments-count"
  }, article.commentsCount || 0)), /*#__PURE__*/React.createElement("div", {
    className: "vote-buttons"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onVote(article.id, 'like');
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: `${appUrl}assets/images/icon-like.png`,
    className: `vote-icon ${currentVote === 'like' ? 'active' : ''}`,
    width: "20",
    height: "auto",
    title: "Like"
  })), /*#__PURE__*/React.createElement("span", {
    className: "like-count"
  }, article.likes || 0), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onVote(article.id, 'dislike');
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: `${appUrl}assets/images/icon-dlike.png`,
    className: `vote-icon ${currentVote === 'dislike' ? 'active' : ''}`,
    width: "20",
    height: "auto",
    title: "Dislike"
  })), /*#__PURE__*/React.createElement("span", {
    className: "dislike-count"
  }, article.dislikes || 0)))));
};
window.ArticleBox = ArticleBox;