
<?php

require_once '../config/bootstrap.php';

$db=new Database();

$contributors = getUserIdByRoleName(('contributor'));


foreach ($contributors as $c){

    echo "<br>Contributor ID: ".$c['id'];
  
}

?>




<style>
body {
    background-color: white; /* **IMPORTANT:** Asigură-te că aceasta este culoarea de fundal a paginii tale */
}

.custom-box {
  width: 50%;
  position: relative;
  background:rgba(255, 255, 255, 0.8); /* Fundalul boxului */
  border: 1px solid rgb(184, 184, 184); /* Bordura completă */
  border-radius: 8px; /* Menținem colțurile rotunde */
  padding: 25px 20px;
  margin: 20px;
}

.corner-label {
  position: absolute;
  top: -25px; /* Poziționează eticheta deasupra bordurii */
  left: 15px; /* Poziția etichetei de la stânga boxului */
  padding: 0 5px; /* Padding pentru spațiul de 10px înainte și după text */
  font-weight: bold;
  background: transparent; /* Fundal transparent pentru etichetă */
  z-index: 1; /* Asigură că eticheta e deasupra elementului care maschează bordura */
  font-size: 20px;
  font-weight: bold;
  white-space: nowrap;
  
}

/* Pseudoelement pentru a "tăia" bordura, având fundalul paginii */
.custom-box::before {
  content: "";
  position: absolute;
  top: -1px; /* La nivelul bordurii de sus */
  height: 1px; /* Suficient de înalt cât să acopere bordura și puțin deasupra */
  background: var(--page-background-color, white); /* **Aici este cheia:** Culoarea fundalului paginii */
  z-index: 1; /* Sub corner-label, dar deasupra bordurii */
  
  /* Lățimea și poziția vor fi setate de JavaScript prin variabile CSS */
  width: var(--cutout-width);
  left: var(--cutout-left);
}

.box-content {
  color: #555;
  line-height: 1.5;
}
</style>



<script>
  /**
   * Inițializează un box personalizat cu o etichetă în colț care întrerupe bordura.
   * @param {HTMLElement} boxElement Elementul .custom-box.
   * @param {string} [pageBgColor] Culoarea de fundal a paginii (opțional).
   * Dacă nu este specificată, se va prelua de la document.body.
   */
  function initializeCustomBox(boxElement, pageBgColor) {
    const cornerLabel = boxElement.querySelector('.corner-label');

    if (!cornerLabel) {
      console.warn('Element .corner-label not found inside custom-box:', boxElement);
      return; // Ieși dacă eticheta nu există
    }

    // Obținem culoarea de fundal a paginii, fie din argument, fie de la body
    const actualPageBackgroundColor = pageBgColor || window.getComputedStyle(document.body).backgroundColor;

    // Setăm o variabilă CSS pe custom-box care să conțină culoarea fundalului paginii
    boxElement.style.setProperty('--page-background-color', actualPageBackgroundColor);

    function updateBorderCutout() {
        // Asigurăm că label-ul este vizibil (chiar dacă este transparent) pentru a calcula lățimea sa
        // Setăm direct display none/block pentru a evita reflow-uri vizuale în timpul calculului
        const originalDisplay = cornerLabel.style.display;
        cornerLabel.style.display = 'inline-block'; // Asigură că primește lățimea corectă
        const labelWidth = cornerLabel.offsetWidth; // Lățimea reală a textului cu padding
        cornerLabel.style.display = originalDisplay; // Restabilim display-ul original


        const labelLeftPosition = parseInt(window.getComputedStyle(cornerLabel).left); // Poziția "left" a etichetei
        
        // paddingAroundText în CSS este `padding: 0 5px;`
        // Dacă vrei 10px în plus înainte și după text, trebuie să adaugi 20px la `labelTextWidth`.
        const extraPaddingForCutout = 30; // Extra padding de 10px înainte și după text

        // Calculăm lățimea totală a zonei pe care vrem să o "tăiem"
        // `labelTextWidth` include deja padding-ul de 5px de pe `corner-label`.
        // Deci, `cutoutWidth` va fi lățimea etichetei + 2 * `extraPaddingForCutout`
        const cutoutWidth = labelWidth + (2 * extraPaddingForCutout);

        // Calculăm poziția de la care începe "tăietura"
        const cutoutLeft = labelLeftPosition - extraPaddingForCutout;

        // Setăm variabilele CSS pe boxElement, pe care pseudoelementul ::before le va folosi
        boxElement.style.setProperty('--cutout-width', `${cutoutWidth}px`);
        boxElement.style.setProperty('--cutout-left', `${cutoutLeft}px`);

        // Ajustăm poziția top a etichetei pentru a o centra pe "tăietură"
        // `height` pentru `::before` este 1px.
        // `top` pentru `::before` este -1px.
        // Centrul vertical al `::before` este la `-1px + (1px / 2) = -0.5px`.
        // Vrem ca centrul vertical al etichetei să fie la această poziție.
        const labelHeight = cornerLabel.offsetHeight;
        const cutoutCenterY = -0.5; // Centrul vertical al pseudoelementului de mascare
        cornerLabel.style.top = `${cutoutCenterY - (labelHeight / 2)}px`;
    }

    // Apelăm funcția de update inițial
    updateBorderCutout();

    // Apelăm funcția și la redimensionarea ferestrei
    window.addEventListener('resize', updateBorderCutout);
  }

  // Când DOM-ul este gata, inițializăm toate box-urile
  document.addEventListener('DOMContentLoaded', () => {
    const allCustomBoxes = document.querySelectorAll('.custom-box');
    allCustomBoxes.forEach(box => {
      initializeCustomBox(box);
    });

    // Exemplu de inițializare cu o culoare de fundal specifică, dacă ar fi cazul
    // const specificBox = document.querySelector('.another-box-style');
    // if (specificBox) {
    //   initializeCustomBox(specificBox, 'lightgray'); // Dacă acest box e pe un fundal gri
    // }
  });
</script>

<br>
<br>
<div class="custom-box">
  <span class="corner-label">Text in colt 1</span>
  <div class="box-content">
    Continutul boxului 1...
  </div>
</div>

<div class="custom-box">
  <span class="corner-label"><img src="../assets/images/icon-view.png" width="25" height="25">&nbsp;Text in colt 2 Looooong Text Here</span>
  <div class="box-content">
    Continutul boxului 2 cu text mai lung...
  </div>
</div>

<div class="custom-box another-box-style">
  <span class="corner-label">Short</span>
  <div class="box-content">
    Continutul boxului 3...
  </div>
</div>


<div class="box-content-1" >
            <ul style="list-style-type: none; width: 100%; padding: 0; margin: 0; text-align: left;padding-top: 10px;">
                <li class="list-item">
                    <div><img src="<?= APP_URL ?>assets/icons/icon-cal-today.svg"></div>
                    <div class="text"><?= lang('lang_db_comments_today') ?></div>
                    <div class="number"><?php echo getTotalComments(24); ?></div>
                </li>
                <li class="list-item">
                    <div><img src="<?= APP_URL ?>assets/icons/icon-cal-week.svg"></div>
                    <div class="text"><?= lang('lang_db_comments_last7days') ?></div>
                    <div class="number"><?php echo getTotalComments(168); ?></div>
                </li>
                <li class="list-item">
                    <div><img src="<?= APP_URL ?>assets/icons/icon-cal-month.svg"></div>
                    <div class="text"><?= lang('lang_db_comments_last_month') ?></div>
                    <div class="number"><?php echo getTotalComments(720); ?></div>
                </li>
            </ul>
        </div>  